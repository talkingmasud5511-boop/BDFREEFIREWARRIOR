/**
 * Converts a Float32Array of PCM audio data to a base64 string.
 */
export function pcmToBase64(float32Array: Float32Array): string {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  
  for (let i = 0; i < float32Array.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  
  return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}

/**
 * Base64 string to audio buffer for playback.
 */
export async function base64ToAudioBuffer(ctx: AudioContext, base64: string): Promise<AudioBuffer> {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  
  const pcm16 = new Int16Array(bytes.buffer);
  const float32 = new Float32Array(pcm16.length);
  for (let i = 0; i < pcm16.length; i++) {
    float32[i] = pcm16[i] / 32768;
  }
  
  const audioBuffer = ctx.createBuffer(1, float32.length, 24000); // Live API uses 24000 for output usually, or 16000. Gemini docs say 24k out.
  audioBuffer.getChannelData(0).set(float32);
  return audioBuffer;
}

/**
 * Audio Queue for smooth playback.
 */
export class AudioQueue {
  private ctx: AudioContext;
  private nextStartTime: number = 0;

  constructor(ctx: AudioContext) {
    this.ctx = ctx;
    this.nextStartTime = ctx.currentTime;
  }

  async play(base64: string) {
    const buffer = await base64ToAudioBuffer(this.ctx, base64);
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(this.ctx.destination);
    
    const startTime = Math.max(this.ctx.currentTime, this.nextStartTime);
    source.start(startTime);
    this.nextStartTime = startTime + buffer.duration;
    
    return source;
  }

  reset() {
    this.nextStartTime = this.ctx.currentTime;
  }
}
