import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Mic, MicOff, Volume2, Sparkles, X, MessageSquare, 
  Power, Code, FileText, Send, Terminal, Settings, 
  ChevronRight, BrainCircuit, Zap
} from "lucide-react";
import { AuraVisualizer } from "./components/AuraVisualizer";
import { pcmToBase64, AudioQueue } from "./lib/audio-utils";

interface ChatMessage {
  id: string;
  sender: 'user' | 'aura';
  text: string;
}

interface WorkspaceState {
  type: 'code' | 'doc' | 'none';
  data: any;
}

export default function App() {
  const [isConnected, setIsConnected] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState<ChatMessage[]>([]);
  const [intensity, setIntensity] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [selectedVoice, setSelectedVoice] = useState("Kore");
  const [workspace, setWorkspace] = useState<WorkspaceState>({ type: 'none', data: null });

  const voices = [
    { id: "Kore", name: "অরা (Kore)", description: "কিউট এবং বন্ধুত্বপূর্ণ" },
    { id: "Puck", name: "পাক (Puck)", description: "চটপটে এবং মজার" },
    { id: "Charon", name: "ক্যারন (Charon)", description: "গম্ভীর এবং পেশাদার" },
    { id: "Fenrir", name: "ফেনরির (Fenrir)", description: "গভীর এবং শক্তিশালী" },
    { id: "Aoede", name: "অয়েড (Aoede)", description: "শান্ত এবং সুমধুর" },
  ];

  const wsRef = useRef<WebSocket | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioQueueRef = useRef<AudioQueue | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcript]);

  const connectAura = useCallback(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws/aura?voice=${selectedVoice}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      setError(null);
    };

    ws.onmessage = async (event) => {
      const msg = JSON.parse(event.data);
      
      if (msg.type === 'audio') {
        if (!audioQueueRef.current && audioCtxRef.current) {
          audioQueueRef.current = new AudioQueue(audioCtxRef.current);
        }
        setIsSpeaking(true);
        await audioQueueRef.current?.play(msg.data);
        setIntensity(0.5);
      }

      if (msg.type === 'text') {
        setTranscript(prev => {
          const last = prev[prev.length - 1];
          if (last && last.sender === 'aura') {
             return [...prev.slice(0, -1), { ...last, text: last.text + msg.text }];
          }
          return [...prev, { id: Date.now().toString(), sender: 'aura', text: msg.text }];
        });
      }

      if (msg.type === 'command') {
        msg.calls.forEach((call: any) => {
          if (call.name === 'open_app' && call.args.url) {
            window.open(call.args.url, '_blank');
          }
          if (call.name === 'write_code') {
            setWorkspace({ type: 'code', data: call.args });
          }
          if (call.name === 'write_document') {
            setWorkspace({ type: 'doc', data: call.args });
          }
          if (call.name === 'send_message') {
            const { platform, contact, message } = call.args;
            if (platform === 'WhatsApp') window.open(`https://wa.me/${contact}?text=${encodeURIComponent(message)}`, '_blank');
            else if (platform === 'SMS') window.open(`sms:${contact}?body=${encodeURIComponent(message)}`, '_blank');
            else window.open(`mailto:${contact}?body=${encodeURIComponent(message)}`, '_blank');
            
            setTranscript(prev => [...prev, { id: Date.now().toString(), sender: 'aura', text: `${contact}-কে ${platform} পাঠানো হচ্ছে।` }]);
          }
        });
      }

      if (msg.type === 'interrupted') {
        audioQueueRef.current?.reset();
        setIsSpeaking(false);
        setIntensity(0);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      stopListening();
    };

    ws.onerror = () => {
      setError("সিস্টেমে ত্রুটি! পুনরায় চেষ্টা করুন।");
    };
  }, [selectedVoice]);

  const disconnectAura = () => {
    wsRef.current?.close();
    stopListening();
    setIsConnected(false);
  };

  const startListening = async () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContext({ sampleRate: 16000 });
      }
      if (audioCtxRef.current.state === 'suspended') await audioCtxRef.current.resume();
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const source = audioCtxRef.current.createMediaStreamSource(stream);
      const processor = audioCtxRef.current.createScriptProcessor(4096, 1, 1);
      
      processor.onaudioprocess = (e) => {
        const input = e.inputBuffer.getChannelData(0);
        let sum = 0;
        for (let i = 0; i < input.length; i++) sum += input[i] * input[i];
        setIntensity(Math.min(1, Math.sqrt(sum / input.length) * 5));

        if (wsRef.current?.readyState === WebSocket.OPEN) {
          const base64 = pcmToBase64(input);
          wsRef.current.send(JSON.stringify({ type: 'audio', data: base64 }));
        }
      };

      source.connect(processor);
      processor.connect(audioCtxRef.current.destination);
      processorRef.current = processor;
      setIsListening(true);
      setError(null);
    } catch (err) {
      setError("মাইক্রোফোন অ্যাক্সেস নেই।");
      console.error(err);
    }
  };

  const stopListening = () => {
    processorRef.current?.disconnect();
    setIsListening(false);
    setIntensity(0);
  };

  return (
    <div className="min-h-screen bg-[#0A0B14] text-slate-200 font-sans selection:bg-indigo-500/30 overflow-hidden">
      {/* Dynamic Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-500/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 flex flex-col h-screen p-4 md:p-6 lg:p-8">
        
        {/* Header */}
        <header className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.4)]">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                Aura AI <span className="text-xs text-indigo-400 font-normal uppercase tracking-widest ml-2">Master</span>
              </h1>
              <p className="text-[10px] text-slate-500 font-medium uppercase tracking-tighter">Powered by Gemini 3.1 Live</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <select 
              disabled={isConnected}
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:ring-1 focus:ring-indigo-500 outline-none backdrop-blur-md disabled:opacity-30"
            >
              {voices.map(v => <option key={v.id} value={v.id} className="bg-slate-900">{v.name}</option>)}
            </select>

            <button 
              onClick={isConnected ? disconnectAura : connectAura}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                isConnected 
                ? 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20' 
                : 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-700'
              }`}
            >
              <Power className="w-3 h-3" />
              {isConnected ? 'নিভিয়ে দাও' : 'চালু কর'}
            </button>
          </div>
        </header>

        {/* Layout Grid */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-6 overflow-hidden">
          
          {/* Left: Visualization & Central Controls (Col 5) */}
          <div className="md:col-span-5 flex flex-col items-center justify-between p-8 bg-white/5 backdrop-blur-xl rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden relative">
            <div className="flex items-center gap-2 mb-4 text-slate-400 text-xs font-medium uppercase tracking-widest">
              <BrainCircuit className="w-4 h-4 text-indigo-400" />
              Neural Activity
            </div>

            <AuraVisualizer 
              isListening={isListening} 
              isSpeaking={isSpeaking} 
              intensity={intensity} 
            />
            
            <div className="text-center space-y-4 max-w-sm">
                <AnimatePresence mode="wait">
                    <motion.h2 
                        key={isListening ? "listen" : isSpeaking ? "speak" : "ready"}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 1.1 }}
                        className="text-3xl font-bold tracking-tight text-white h-10"
                    >
                        {isListening ? "শুনছি..." : isSpeaking ? "কথা বলছি..." : "আমি প্রস্তুত!"}
                    </motion.h2>
                </AnimatePresence>
                <p className="text-slate-400 text-sm h-12 leading-relaxed">
                    {isConnected 
                        ? (isListening ? "আপনার নির্দেশ দিন, আমি সব মনোযোগ দিয়ে শুনছি।" : "আমাকে কিছু জিজ্ঞাসা করুন বা কোনো কাজ করতে বলুন।") 
                        : "কথা শুরু করার জন্য উপরের বাটনে ক্লিক করে যুক্ত হন।"}
                </p>
            </div>

            <div className="flex gap-6 items-center">
                <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    disabled={!isConnected}
                    onClick={isListening ? stopListening : startListening}
                    className={`group w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                        isListening 
                        ? 'bg-red-500 shadow-[0_0_40px_rgba(239,68,68,0.4)]' 
                        : 'bg-white shadow-[0_0_30px_rgba(255,255,255,0.1)]'
                    } disabled:opacity-30`}
                >
                    {isListening 
                        ? <MicOff className="w-8 h-8 text-white" /> 
                        : <Mic className="w-8 h-8 text-indigo-600 group-hover:scale-110 transition-transform" />
                    }
                </motion.button>
            </div>
          </div>

          {/* Right: Multi-View Workspace (Col 7) */}
          <div className="md:col-span-7 flex flex-col gap-6 overflow-hidden">
            
            {/* Workspace / Content Viewer */}
            <div className={`flex-1 bg-white/5 backdrop-blur-xl rounded-[2rem] border border-white/10 shadow-lg flex flex-col overflow-hidden transition-all duration-500 ${workspace.type === 'none' ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/[0.02]">
                    <div className="flex items-center gap-3">
                        {workspace.type === 'code' ? <Code className="w-5 h-5 text-indigo-400" /> : <FileText className="w-5 h-5 text-emerald-400" />}
                        <span className="text-sm font-semibold text-slate-300">
                            {workspace.type === 'code' ? (workspace.data.filename || "Generated Code") : (workspace.data?.title || "Document")}
                        </span>
                    </div>
                    <button onClick={() => setWorkspace({ type: 'none', data: null })} className="p-2 hover:bg-white/10 rounded-lg text-slate-500">
                        <X className="w-4 h-4" />
                    </button>
                </div>
                <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed text-slate-400">
                    {workspace.type === 'code' && (
                        <div className="space-y-4">
                            <div className="flex gap-2">
                                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-400 rounded uppercase tracking-tighter">{workspace.data.language}</span>
                            </div>
                            <pre className="p-4 bg-black/40 rounded-xl border border-white/5 text-slate-300 whitespace-pre-wrap select-all">
                                {workspace.data.code}
                            </pre>
                        </div>
                    )}
                    {workspace.type === 'doc' && (
                        <div className="max-w-prose space-y-4 text-sm font-sans text-slate-300 leading-loose">
                            <h3 className="text-xl font-bold text-white">{workspace.data.title}</h3>
                            <div className="whitespace-pre-wrap">{workspace.data.content}</div>
                        </div>
                    )}
                    {workspace.type === 'none' && (
                        <div className="h-full flex flex-col items-center justify-center text-slate-600 gap-4">
                            <Terminal className="w-12 h-12 opacity-20" />
                            <p>যখন আপনি আমাকে কোড বা কিছু লিখতে বলবেন, তা এখানে দেখা যাবে।</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Compact Chat History */}
            <div className="h-64 bg-white/5 backdrop-blur-xl rounded-[2rem] border border-white/10 shadow-lg p-6 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-2 text-slate-400 font-bold text-[10px] uppercase tracking-widest">
                    <MessageSquare className="w-3 h-3 text-indigo-400" />
                    Conversational Log
                 </div>
                 <button onClick={() => setTranscript([])} className="text-[10px] text-slate-500 hover:text-white transition-colors">হিস্ট্রি মুছুন</button>
              </div>
              
              <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
                {transcript.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center px-4">
                        <Volume2 className="w-4 h-4 mb-2 opacity-20" />
                        <p className="text-[10px]">Neural logs are empty.</p>
                    </div>
                )}
                {transcript.map((msg) => (
                  <motion.div key={msg.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex gap-2 group">
                    <span className={`text-[10px] font-bold ${msg.sender === 'user' ? 'text-indigo-400' : 'text-purple-400'}`}>{msg.sender.toUpperCase()}:</span>
                    <span className="text-xs text-slate-400 leading-normal">{msg.text}</span>
                  </motion.div>
                ))}
                <div ref={transcriptEndRef} />
              </div>
            </div>

          </div>
        </div>

        {/* Global Footer */}
        <footer className="mt-6 flex justify-between items-center text-[10px] text-slate-600 font-medium uppercase tracking-widest">
            <div className="flex gap-4">
                <span className="flex items-center gap-1 hover:text-indigo-400 cursor-help transition-colors"><Settings className="w-3 h-3" /> System Diagnostics</span>
                <span className="flex items-center gap-1 hover:text-indigo-400 cursor-help transition-colors"><ChevronRight className="w-3 h-3" /> API: Stable</span>
            </div>
            <div className="flex gap-2">
                <span className="text-slate-700">Aura AI 3.1 Legacy Framework</span>
            </div>
        </footer>
      </div>

      {/* Connection Glow */}
      <AnimatePresence>
        {isConnected && (
            <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                className="fixed top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent blur-sm animate-pulse"
            />
        )}
      </AnimatePresence>
    </div>
  );
}
