import { motion, AnimatePresence } from "motion/react";

interface AuraVisualizerProps {
  isListening: boolean;
  isSpeaking: boolean;
  intensity: number;
}

export const AuraVisualizer = ({ isListening, isSpeaking, intensity }: AuraVisualizerProps) => {
  return (
    <div className="relative flex items-center justify-center w-80 h-80">
      {/* Neural Network Environment */}
      <div className="absolute inset-0 flex items-center justify-center">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute border border-indigo-500/10 rounded-full"
            style={{ width: 300 + i * 80, height: 300 + i * 80 }}
            animate={{ 
              rotate: i % 2 === 0 ? 360 : -360,
              scale: isSpeaking ? [1, 1.05, 1] : 1 
            }}
            transition={{ duration: 10 + i * 5, repeat: Infinity, ease: "linear" }}
          />
        ))}
      </div>

      {/* Background Volumetric Glow */}
      <motion.div
        className="absolute w-[400px] h-[400px] rounded-full bg-indigo-600/10 blur-[100px]"
        animate={{
          scale: isSpeaking ? [1, 1.3, 1] : [1, 1.1, 1],
          opacity: isListening || isSpeaking ? 0.4 : 0.2,
        }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* The Master Core (Glassmorphic Orb) */}
      <motion.div
        className="relative z-10 w-48 h-48 rounded-full shadow-[0_0_100px_rgba(99,102,241,0.3)] flex items-center justify-center overflow-hidden border border-white/30"
        style={{
          background: "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.2) 0%, rgba(99,102,241,0.1) 100%)",
          backdropFilter: "blur(12px)",
        }}
        animate={{
          scale: isSpeaking ? 1 + (intensity * 0.3) : (isListening ? [1, 1.02, 1] : 1),
        }}
        transition={{ type: "spring", stiffness: 300, damping: 15 }}
      >
        {/* Internal Flowing Plasma */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: "conic-gradient(from 0deg, transparent, #6366f1, #a855f7, #6366f1, transparent)",
            opacity: 0.4,
            filter: "blur(20px)",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />

        {/* The Central Neural Node */}
        <motion.div 
            className="relative z-20 w-16 h-16 bg-white rounded-full shadow-[0_0_40px_rgba(255,255,255,0.8)]"
            animate={{
                scale: isSpeaking ? [1, 1.5, 1] : 1,
                opacity: isSpeaking ? [0.8, 1, 0.8] : 0.9,
                boxShadow: isSpeaking 
                    ? `0 0 ${40 + intensity * 60}px rgba(255,255,255,1)`
                    : "0 0 20px rgba(255,255,255,0.5)",
            }}
        >
            <div className="absolute inset-0 bg-indigo-500 rounded-full blur-[2px] opacity-20" />
        </motion.div>

        {/* Data Particles */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-50, 50],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </motion.div>

      {/* Cybernetic HUD Rings */}
      <div className="absolute inset-0 pointer-events-none">
        <svg viewBox="0 0 100 100" className="w-full h-full opacity-20">
          <motion.circle
            cx="50" cy="50" r="45"
            fill="none" stroke="currentColor" strokeWidth="0.2"
            strokeDasharray="1 4"
            className="text-indigo-400"
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          />
          <motion.circle
            cx="50" cy="50" r="48"
            fill="none" stroke="currentColor" strokeWidth="0.1"
            className="text-purple-400"
            animate={{ rotate: -360 }}
            transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
          />
        </svg>
      </div>
    </div>
  );
};
