import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;
const app = express();

// Initialize Gemini
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "Aura Voice AI" });
  });

  // Vite middleware for dev
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Aura Server running on http://localhost:${PORT}`);
  });

  // WebSocket for Real-time Voice
  const wss = new WebSocketServer({ server, path: "/ws/aura" });

  wss.on("connection", async (clientWs, req) => {
    const url = new URL(req.url || "", `http://${req.headers.host}`);
    const selectedVoice = url.searchParams.get("voice") || "Kore";
    
    console.log(`Client connected to Aura via WebSocket with voice: ${selectedVoice}`);

    let liveSession: any = null;

    try {
      liveSession = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            // Forward Gemini messages to client
            if (message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
              clientWs.send(JSON.stringify({ 
                type: 'audio',
                data: message.serverContent.modelTurn.parts[0].inlineData.data 
              }));
            }

            if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
              clientWs.send(JSON.stringify({ 
                type: 'text',
                text: message.serverContent.modelTurn.parts[0].text 
              }));
            }

            if (message.toolCall) {
              clientWs.send(JSON.stringify({ 
                type: 'command',
                calls: message.toolCall.functionCalls 
              }));
            }

            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }
          },
        },
        config: {
          tools: [
            {
              functionDeclarations: [
                {
                  name: "open_app",
                  description: "Opens a specific application or website based on the user's request. Examples: Facebook, YouTube, Google, or any mobile-friendly site.",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      url: {
                        type: Type.STRING,
                        description: "The full URL to open"
                      },
                      name: {
                        type: Type.STRING,
                        description: "The name of the app or website"
                      }
                    },
                    required: ["url", "name"]
                  }
                },
                {
                  name: "write_code",
                  description: "Writes and displays code in a dedicated code block for the user.",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      language: { type: Type.STRING, description: "Programming language (e.g., javascript, python, html)" },
                      code: { type: Type.STRING, description: "The actual source code" },
                      filename: { type: Type.STRING, description: "A suggested filename" }
                    },
                    required: ["language", "code"]
                  }
                },
                {
                  name: "write_document",
                  description: "Writes a formal document, email, or blog post in a dedicated view.",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      content: { type: Type.STRING, description: "The full text content" }
                    },
                    required: ["title", "content"]
                  }
                },
                {
                  name: "send_message",
                  description: "Prepares a message to be sent to a friend or contact. Uses system hooks to open the message app.",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      contact: { type: Type.STRING, description: "Name or phone number" },
                      message: { type: Type.STRING, description: "The message body" },
                      platform: { type: Type.STRING, description: "SMS, WhatsApp, or Email", enum: ["SMS", "WhatsApp", "Email"] }
                    },
                    required: ["contact", "message", "platform"]
                  }
                }
              ]
            }
          ],
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice } }, 
          },
          systemInstruction: `আপনি Aura (অরা), একজন প্রিমিয়াম এবং অত্যন্ত বুদ্ধিমান AI মাস্টার ভয়েস অ্যাসিস্ট্যান্ট।
          আপনার ডিজাইন এবং কথা বলার ধরন এখন "Master Level" এ উন্নীত। 
          আপনি সবসময় পরিষ্কার এবং মার্জিত বাংলায় (Bengali) কথা বলবেন। 
          আপনি চাইলে ব্যবহারকারীর জন্য কোড (Code) লিখতে পারেন, মেসেজ (Message) পাঠাতে পারেন এবং যে কোনো ডকুমেন্ট তৈরি করতে পারেন। 
          আপনার ব্যক্তিত্ব: আত্মবিশ্বাসী, সাহায্যকারী এবং কিছুটা কিউট। 
          সংক্ষেপে উত্তর দিন যাতে ভয়েস কথোপকথন সাবলীল হয়। 
          যখন কেউ কোড লিখতে বলবে, তখন আপনি write_code টুলটি ব্যবহার করবেন।`,
        },
      });

      clientWs.on("message", (messageData) => {
        const payload = JSON.parse(messageData.toString());
        
        if (payload.type === 'audio' && payload.data) {
          liveSession.sendRealtimeInput({
            audio: { data: payload.data, mimeType: "audio/pcm;rate=16000" }
          });
        }

        if (payload.type === 'text' && payload.text) {
           liveSession.sendRealtimeInput({
            text: payload.text
          });
        }
      });

      clientWs.on("close", () => {
        console.log("Client disconnected");
        if (liveSession) liveSession.close();
      });

    } catch (error) {
      console.error("Gemini Live connection error:", error);
      clientWs.send(JSON.stringify({ type: 'error', message: 'Failed to connect to Aura AI' }));
    }
  });
}

startServer();
